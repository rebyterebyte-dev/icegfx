import { useCallback, useMemo, useRef, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { toast } from "@/hooks/use-toast";
import { generateThumbnailWithAI } from "@/lib/thumbnail-ai";
import { PLAN_CONFIG } from "@/lib/plans";
import { TEMPLATES } from "./thumbnail-editor/constants";
import { StudioCanvas } from "./thumbnail-editor/StudioCanvas";
import { ToolsPanel } from "./thumbnail-editor/ToolsPanel";
import type { CreativityLevel, GenerationMode } from "./thumbnail-editor/types";

interface ThumbnailHistoryItem {
  id: string;
  image: string;
  fullImage?: string | null;
  prompt: string;
  createdAt: string;
  userId: string;
  template: string | null;
  mode: GenerationMode;
}

const HISTORY_KEY = "bt_thumbnails";

async function createCompressedPreview(imageSrc: string): Promise<string | null> {
  if (!imageSrc.startsWith("data:image")) return imageSrc;

  return new Promise((resolve) => {
    const image = new Image();
    image.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = 480;
        canvas.height = 270;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(null);
          return;
        }
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.72));
      } catch {
        resolve(null);
      }
    };
    image.onerror = () => resolve(null);
    image.src = imageSrc;
  });
}

function readHistory(): ThumbnailHistoryItem[] {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
  } catch {
    return [];
  }
}

function writeHistorySafe(items: ThumbnailHistoryItem[]) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 24)));
  } catch (error) {
    if (error instanceof DOMException && error.name === "QuotaExceededError") {
      const reduced = items.slice(0, 8).map((item) => ({ ...item, image: item.image.slice(0, 120000) }));
      try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(reduced));
      } catch {
        localStorage.removeItem(HISTORY_KEY);
      }
    }
  }
}

export function ThumbnailEditor() {
  const { user, updateCredits } = useAuth();
  const [thumbnailImage, setThumbnailImage] = useState<string | null>(null);
  const [skinImage, setSkinImage] = useState<string | null>(null);
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null);
  const [selectedSubTool, setSelectedSubTool] = useState<string | null>(null);
  const [creativity, setCreativity] = useState<CreativityLevel>("balanced");
  const [zoomLevel, setZoomLevel] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [fitMode, setFitMode] = useState<"contain" | "cover">("contain");

  const fileInputRef = useRef<HTMLInputElement>(null);
  const skinInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>, setter: (v: string) => void) => {
    const file = e.target.files?.[0];
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setter(ev.target?.result as string);
      setGeneratedImage(null);
      setZoomLevel(1);
      setRotation(0);
      setFitMode("contain");
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  }, []);

  const handleYoutubeLoad = useCallback(() => {
    if (!youtubeUrl.trim()) return;
    const match = youtubeUrl.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([a-zA-Z0-9_-]{11})/);

    if (!match) {
      toast({ title: "Fehler", description: "Ungültiger YouTube Link.", variant: "destructive" });
      return;
    }

    setThumbnailImage(`https://img.youtube.com/vi/${match[1]}/maxresdefault.jpg`);
    setGeneratedImage(null);
    setZoomLevel(1);
    setRotation(0);
    setFitMode("contain");
    toast({ title: "Thumbnail geladen", description: "YouTube Thumbnail wurde erfolgreich geladen." });
  }, [youtubeUrl]);

  const saveHistory = useCallback(
    async (resultImage: string, mode: GenerationMode, templateName: string | null, instruction: string) => {
      if (!user) return;

      const compressedPreview = await createCompressedPreview(resultImage);
      const history = readHistory();
      history.unshift({
        id: crypto.randomUUID(),
        image: compressedPreview || resultImage,
        fullImage: resultImage.startsWith("http") ? resultImage : null,
        prompt: prompt || instruction,
        createdAt: new Date().toISOString(),
        userId: user.id,
        template: templateName,
        mode,
      });
      writeHistorySafe(history);
    },
    [prompt, user],
  );

  const runGeneration = useCallback(
    async (mode: GenerationMode, requireTemplate = false) => {
      const sourceImage = generatedImage || thumbnailImage;

      if (!sourceImage) {
        toast({ title: "Kein Bild", description: "Bitte lade zuerst ein Thumbnail hoch.", variant: "destructive" });
        return;
      }

      if (requireTemplate && selectedTemplate === null) {
        toast({ title: "Template fehlt", description: "Bitte wähle zuerst ein Template aus.", variant: "destructive" });
        return;
      }

      if (!user || user.credits < 10) {
        toast({ title: "Nicht genug Credits", description: "Du brauchst mindestens 10 Credits.", variant: "destructive" });
        return;
      }

      setIsGenerating(true);

      try {
        const template = selectedTemplate !== null ? TEMPLATES[selectedTemplate] : null;
        const output = PLAN_CONFIG[user.plan].output;

        const result = await generateThumbnailWithAI({
          sourceImage,
          skinImage,
          prompt,
          mode,
          creativity,
          templateInstruction: template?.instruction,
          subToolInstruction: selectedSubTool,
          outputWidth: output.width,
          outputHeight: output.height,
          plan: user.plan,
        });

        setGeneratedImage(result.image);
        setZoomLevel(1);
        setRotation(0);
        setFitMode("contain");
        updateCredits(-10);

        await saveHistory(result.image, mode, template?.name || null, result.instruction);

        toast({
          title: mode === "remix" ? "Remix erstellt!" : "Thumbnail erstellt!",
          description: `10 Credits wurden abgezogen · ${PLAN_CONFIG[user.plan].resolution} Ausgabe.`,
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : "Unbekannter Fehler";
        toast({ title: "Generierung fehlgeschlagen", description: message, variant: "destructive" });
      } finally {
        setIsGenerating(false);
      }
    },
    [
      generatedImage,
      thumbnailImage,
      selectedTemplate,
      user,
      skinImage,
      prompt,
      creativity,
      selectedSubTool,
      updateCredits,
      saveHistory,
    ],
  );

  const handleGenerate = useCallback(() => runGeneration("generate"), [runGeneration]);
  const handleRemix = useCallback(() => runGeneration("remix"), [runGeneration]);
  const handleTemplateGenerate = useCallback(() => runGeneration("generate", true), [runGeneration]);

  const handleDownload = useCallback(async () => {
    const image = generatedImage || thumbnailImage;
    if (!image) return;

    try {
      const response = await fetch(image);
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = objectUrl;
      link.download = `ideaminds-thumbnail-${Date.now()}.png`;
      link.click();
      URL.revokeObjectURL(objectUrl);
    } catch {
      const link = document.createElement("a");
      link.href = image;
      link.download = `ideaminds-thumbnail-${Date.now()}.png`;
      link.click();
    }
  }, [generatedImage, thumbnailImage]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setThumbnailImage(ev.target?.result as string);
      setGeneratedImage(null);
      setZoomLevel(1);
      setRotation(0);
      setFitMode("contain");
    };
    reader.readAsDataURL(file);
  }, []);

  const displayImage = useMemo(() => generatedImage || thumbnailImage, [generatedImage, thumbnailImage]);
  const canGenerate = Boolean(thumbnailImage || generatedImage);
  const canRemix = Boolean(thumbnailImage || generatedImage);
  const canGenerateWithTemplate = canGenerate && selectedTemplate !== null;

  return (
    <div className="flex flex-1 gap-0 h-full overflow-hidden bg-background">
      <StudioCanvas
        displayImage={displayImage}
        isGenerating={isGenerating}
        zoomLevel={zoomLevel}
        rotation={rotation}
        fitMode={fitMode}
        onDrop={handleDrop}
        onUploadClick={() => fileInputRef.current?.click()}
        onDownload={handleDownload}
        onZoomIn={() => setZoomLevel((z) => Math.min(2.5, z + 0.1))}
        onZoomOut={() => setZoomLevel((z) => Math.max(0.6, z - 0.1))}
        onResetView={() => {
          setZoomLevel(1);
          setRotation(0);
          setFitMode("contain");
        }}
        onToggleFitMode={() => {
          setRotation((r) => (r + 90) % 360);
          setFitMode((m) => (m === "contain" ? "cover" : "contain"));
        }}
        activeTemplateName={selectedTemplate !== null ? TEMPLATES[selectedTemplate]?.name : undefined}
      />

      <ToolsPanel
        youtubeUrl={youtubeUrl}
        onYoutubeUrlChange={setYoutubeUrl}
        onYoutubeLoad={handleYoutubeLoad}
        prompt={prompt}
        onPromptChange={setPrompt}
        skinImage={skinImage}
        onThumbnailUploadClick={() => fileInputRef.current?.click()}
        onSkinUploadClick={() => skinInputRef.current?.click()}
        selectedTemplate={selectedTemplate}
        onSelectTemplate={setSelectedTemplate}
        selectedSubTool={selectedSubTool}
        onSelectSubTool={setSelectedSubTool}
        creativity={creativity}
        onCreativityChange={setCreativity}
        onGenerate={handleGenerate}
        onRemix={handleRemix}
        onGenerateWithTemplate={handleTemplateGenerate}
        isGenerating={isGenerating}
        canGenerate={canGenerate}
        canRemix={canRemix}
        canGenerateWithTemplate={canGenerateWithTemplate}
      />

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleImageUpload(e, setThumbnailImage)}
      />
      <input
        ref={skinInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleImageUpload(e, setSkinImage)}
      />
    </div>
  );
}
