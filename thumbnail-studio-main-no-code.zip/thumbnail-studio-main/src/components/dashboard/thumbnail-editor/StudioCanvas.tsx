import { Download, ImageIcon, RotateCw, ZoomIn, ZoomOut, Maximize2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";

interface StudioCanvasProps {
  displayImage: string | null;
  isGenerating: boolean;
  zoomLevel: number;
  rotation: number;
  fitMode: "contain" | "cover";
  onDrop: (e: React.DragEvent) => void;
  onUploadClick?: () => void;
  onDownload: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetView: () => void;
  onToggleFitMode: () => void;
  activeTemplateName?: string;
}

export function StudioCanvas({
  displayImage,
  isGenerating,
  zoomLevel,
  rotation,
  fitMode,
  onDrop,
  onUploadClick,
  onDownload,
  onZoomIn,
  onZoomOut,
  onResetView,
  onToggleFitMode,
  activeTemplateName,
}: StudioCanvasProps) {
  return (
    <section className="flex-1 flex flex-col min-w-0 p-6 studio-grid-bg">
      <div className="flex items-center gap-3 mb-4">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-primary/15 border border-primary/30">
          <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
          <span className="text-xs font-medium text-primary">MAIN</span>
        </div>
        <h2 className="text-sm font-medium text-muted-foreground">IdeaMinds Studio</h2>
        {activeTemplateName && (
          <span className="text-xs px-2 py-0.5 rounded-full border border-border bg-secondary text-secondary-foreground ml-auto">
            {activeTemplateName}
          </span>
        )}
        <Button size="sm" variant="outline" className="gap-1.5 ml-auto" onClick={onUploadClick}>
          <Upload className="h-3.5 w-3.5" /> Upload
        </Button>
      </div>

      <div
        className="flex-1 flex items-center justify-center rounded-2xl border border-border bg-muted/20 overflow-hidden relative"
        style={{ aspectRatio: "1280/720", maxHeight: "560px" }}
        onDragOver={(e) => e.preventDefault()}
        onDrop={onDrop}
      >
        {displayImage ? (
          <img
            src={displayImage}
            alt="Thumbnail Vorschau"
            className={`w-full h-full ${fitMode === "cover" ? "object-cover" : "object-contain"}`}
            loading="lazy"
            style={{
              imageRendering: "auto",
              transform: `scale(${zoomLevel}) rotate(${rotation}deg)`,
              transformOrigin: "center",
              transition: "transform 180ms ease",
            }}
          />
        ) : (
          <div className="text-center text-muted-foreground px-6">
            <div className="h-16 w-16 mx-auto mb-4 rounded-2xl bg-muted/60 border border-border flex items-center justify-center">
              <ImageIcon className="h-8 w-8 opacity-50" />
            </div>
            <p className="text-sm font-medium">Lade ein Thumbnail hoch</p>
            <p className="text-xs mt-1 text-muted-foreground">Drag & Drop oder Upload oben rechts</p>
          </div>
        )}

        {isGenerating && (
          <div className="absolute inset-0 bg-background/85 backdrop-blur-sm flex items-center justify-center">
            <div className="text-center">
              <RotateCw className="h-8 w-8 text-primary animate-spin mx-auto mb-2" />
              <p className="text-sm font-medium">AI generiert dein Thumbnail…</p>
            </div>
          </div>
        )}
      </div>

      <div className="mx-auto mt-4 w-fit rounded-full border border-border bg-card/90 backdrop-blur-sm px-1.5 py-1 flex items-center gap-1">
        <Button size="icon" variant="ghost" className="rounded-full h-8 w-8" onClick={onZoomOut} disabled={!displayImage}>
          <ZoomOut className="h-3.5 w-3.5" />
        </Button>
        <Button size="icon" variant="ghost" className="rounded-full h-8 w-8" onClick={onZoomIn} disabled={!displayImage}>
          <ZoomIn className="h-3.5 w-3.5" />
        </Button>
        <span className="text-xs px-2 text-muted-foreground min-w-12 text-center">{Math.round(zoomLevel * 100)}%</span>
        <Button size="icon" variant="ghost" className="rounded-full h-8 w-8" onClick={onResetView} disabled={!displayImage}>
          <RotateCw className="h-3.5 w-3.5" />
        </Button>
        <Button size="icon" variant="ghost" className="rounded-full h-8 w-8" onClick={onToggleFitMode} disabled={!displayImage}>
          <Maximize2 className="h-3.5 w-3.5" />
        </Button>
        <Button size="icon" variant="ghost" className="rounded-full h-8 w-8" onClick={onDownload} disabled={!displayImage}>
          <Download className="h-3.5 w-3.5" />
        </Button>
      </div>
    </section>
  );
}
