import { useMemo, useState } from "react";
import { Link as LinkIcon, Upload, Wand2, RotateCw, Sparkles, ImagePlus, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CREATIVITY_OPTIONS, TEMPLATES } from "./constants";
import type { CreativityLevel } from "./types";

interface ToolsPanelProps {
  youtubeUrl: string;
  onYoutubeUrlChange: (value: string) => void;
  onYoutubeLoad: () => void;
  prompt: string;
  onPromptChange: (value: string) => void;
  skinImage: string | null;
  onThumbnailUploadClick: () => void;
  onSkinUploadClick: () => void;
  selectedTemplate: number | null;
  onSelectTemplate: (index: number) => void;
  selectedSubTool: string | null;
  onSelectSubTool: (instruction: string | null) => void;
  creativity: CreativityLevel;
  onCreativityChange: (value: CreativityLevel) => void;
  onGenerate: () => void;
  onRemix: () => void;
  onGenerateWithTemplate: () => void;
  isGenerating: boolean;
  canGenerate: boolean;
  canRemix: boolean;
  canGenerateWithTemplate: boolean;
}

export function ToolsPanel({
  youtubeUrl,
  onYoutubeUrlChange,
  onYoutubeLoad,
  prompt,
  onPromptChange,
  skinImage,
  onThumbnailUploadClick,
  onSkinUploadClick,
  selectedTemplate,
  onSelectTemplate,
  selectedSubTool,
  onSelectSubTool,
  creativity,
  onCreativityChange,
  onGenerate,
  onRemix,
  onGenerateWithTemplate,
  isGenerating,
  canGenerate,
  canRemix,
  canGenerateWithTemplate,
}: ToolsPanelProps) {
  const [tab, setTab] = useState<"editor" | "inspiration">("editor");
  const [search, setSearch] = useState("");

  const filteredTemplates = useMemo(() => {
    if (!search.trim()) return TEMPLATES;
    const query = search.toLowerCase();
    return TEMPLATES.filter((t) => t.name.toLowerCase().includes(query) || t.summary.toLowerCase().includes(query));
  }, [search]);

  const selectedTemplateData = selectedTemplate !== null ? TEMPLATES[selectedTemplate] : null;

  const handleSelectTemplate = (index: number) => {
    onSelectTemplate(index);
    onSelectSubTool(null);
  };

  const handleMainAction = () => {
    if (selectedTemplate !== null) {
      onGenerateWithTemplate();
      return;
    }
    onGenerate();
  };

  return (
    <aside className="w-[360px] border-l border-border bg-card/70 backdrop-blur-sm flex flex-col">
      <div className="border-b border-border flex px-2 pt-2 gap-2">
        <button
          onClick={() => setTab("editor")}
          className={`flex-1 px-4 py-2 rounded-t-lg text-sm font-medium transition-colors flex items-center justify-center gap-1.5 ${
            tab === "editor" ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Wand2 className="h-3.5 w-3.5" /> Editor
        </button>
        <button
          onClick={() => setTab("inspiration")}
          className={`flex-1 px-4 py-2 rounded-t-lg text-sm font-medium transition-colors flex items-center justify-center gap-1.5 ${
            tab === "inspiration" ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Sparkles className="h-3.5 w-3.5" /> Inspiration
        </button>
      </div>

      {tab === "editor" ? (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="p-4 space-y-4 overflow-y-auto">
            <div className="space-y-2">
              <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">AI Modus</p>
              <div className="grid grid-cols-3 gap-2">
                {CREATIVITY_OPTIONS.map((option) => {
                  const active = creativity === option.id;
                  return (
                    <button
                      key={option.id}
                      onClick={() => onCreativityChange(option.id)}
                      className={`rounded-lg border p-2 text-left transition-colors ${
                        active ? "border-primary bg-primary/15" : "border-border bg-secondary/20 hover:border-primary/60"
                      }`}
                    >
                      <p className="text-xs font-medium">{option.name}</p>
                      <p className="text-[10px] text-muted-foreground">{option.subtitle}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Tools Library</p>
                <Input
                  placeholder="Suche"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="h-7 w-28 text-xs"
                />
              </div>
              <div className="grid grid-cols-2 gap-2 max-h-[180px] overflow-auto pr-1">
                {filteredTemplates.map((template) => {
                  const index = TEMPLATES.findIndex((x) => x.id === template.id);
                  const active = selectedTemplate === index;
                  return (
                    <button
                      key={template.id}
                      onClick={() => handleSelectTemplate(index)}
                      className={`rounded-xl border p-3 text-left transition-colors ${
                        active ? "border-primary bg-primary/15" : "border-border bg-secondary/20 hover:border-primary/60"
                      }`}
                    >
                      <p className="text-base mb-1">{template.icon}</p>
                      <p className="text-xs font-medium">{template.name}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{template.summary}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {selectedTemplateData?.subTools && (
              <div className="space-y-2">
                <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">{selectedTemplateData.name} Optionen</p>
                <div className="grid grid-cols-2 gap-2">
                  {selectedTemplateData.subTools.map((st) => {
                    const active = selectedSubTool === st.instruction;
                    return (
                      <button
                        key={st.label}
                        onClick={() => onSelectSubTool(st.instruction)}
                        className={`rounded-lg border p-2 text-left transition-colors ${
                          active ? "border-primary bg-primary/15" : "border-border bg-secondary/20 hover:border-primary/60"
                        }`}
                      >
                        <p className="text-xs font-medium">{st.label}</p>
                        <p className="text-[10px] text-muted-foreground">{st.description}</p>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" size="sm" onClick={onThumbnailUploadClick}>
                <ImagePlus className="h-3.5 w-3.5 mr-1" /> Thumbnail
              </Button>
              <Button variant="outline" size="sm" onClick={onSkinUploadClick}>
                <Upload className="h-3.5 w-3.5 mr-1" /> Skin
              </Button>
            </div>

            {skinImage && <img src={skinImage} alt="Skin Referenz" className="h-20 rounded-lg border border-border object-cover" loading="lazy" />}

            <div className="space-y-1.5">
              <label className="text-xs text-muted-foreground block">YouTube Link</label>
              <div className="flex gap-2">
                <Input
                  placeholder="https://youtube.com/watch?v=..."
                  value={youtubeUrl}
                  onChange={(e) => onYoutubeUrlChange(e.target.value)}
                  className="text-xs"
                />
                <Button size="sm" variant="outline" onClick={onYoutubeLoad}>
                  <LinkIcon className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          </div>

          <div className="p-4 border-t border-border bg-background/60 space-y-3">
            <div className="rounded-xl border border-border bg-card p-2">
              <Textarea
                placeholder="Beschreibe dein gewünschtes Thumbnail..."
                value={prompt}
                onChange={(e) => onPromptChange(e.target.value)}
                rows={2}
                className="border-0 bg-transparent p-1 text-xs resize-none focus-visible:ring-0"
              />
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-1">
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={onThumbnailUploadClick}>
                    <Upload className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onSelectSubTool(selectedSubTool ? null : "Clean up artifacts and optimize sharpness") }>
                    <Wrench className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <Button className="h-8 px-4" onClick={handleMainAction} disabled={isGenerating || !canGenerate || (selectedTemplate !== null && !canGenerateWithTemplate)}>
                  <Wand2 className="h-3.5 w-3.5 mr-1" /> Edit
                </Button>
              </div>
            </div>

            <Button variant="outline" className="w-full" onClick={onRemix} disabled={!canRemix || isGenerating}>
              <RotateCw className="h-4 w-4 mr-1" /> Remix (10 Credits)
            </Button>
          </div>
        </div>
      ) : (
        <InspirationTab />
      )}
    </aside>
  );
}

function InspirationTab() {
  const tags = ["Gaming", "Minecraft", "Fortnite", "Valorant", "Reaction", "Challenge"];
  return (
    <div className="flex-1 p-4 space-y-4">
      <Input placeholder="Search topics..." className="text-sm" />
      <div className="flex flex-wrap gap-2">
        {tags.map((tag) => (
          <button
            key={tag}
            className="px-3 py-1.5 rounded-full border border-border bg-secondary/30 text-xs font-medium hover:border-primary/50 transition-colors"
          >
            {tag}
          </button>
        ))}
      </div>
      <div className="flex-1 flex flex-col items-center justify-center text-center py-16">
        <div className="h-12 w-12 rounded-full bg-muted/60 border border-border flex items-center justify-center mb-3">
          <Sparkles className="h-5 w-5 text-muted-foreground" />
        </div>
        <p className="text-sm text-muted-foreground">Wähle ein Thema für Vorschläge</p>
      </div>
    </div>
  );
}
