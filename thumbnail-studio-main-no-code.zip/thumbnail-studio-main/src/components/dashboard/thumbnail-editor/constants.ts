import type { ThumbnailTemplate } from "./types";

export const TEMPLATES: ThumbnailTemplate[] = [
  {
    id: 1,
    name: "Reaction Shot",
    summary: "Große Emotion + klare Story",
    icon: "😲",
    instruction:
      "Turn this into a high-energy reaction thumbnail with expressive face lighting, strong foreground subject separation and readable composition for YouTube CTR. Do NOT add any text.",
  },
  {
    id: 2,
    name: "Before & After",
    summary: "Starker Kontrast vorher/nachher",
    icon: "🔄",
    instruction:
      "Create a split-style before-and-after thumbnail with dramatic visual contrast while keeping the original topic and making the transition obvious. Do NOT add any text.",
  },
  {
    id: 3,
    name: "Challenge",
    summary: "Spannung + Wettkampf",
    icon: "⚔️",
    instruction:
      "Design this as a challenge thumbnail: bold tension, dynamic framing, and visual cues that suggest competition and stakes. Do NOT add any text, titles, or written words whatsoever.",
  },
  {
    id: 4,
    name: "Tutorial",
    summary: "Sauber + klarer Lernfokus",
    icon: "📚",
    instruction:
      "Transform this into a tutorial-style thumbnail: clean composition, clear focal point, and educational clarity without clutter. Do NOT add any text.",
  },
  {
    id: 5,
    name: "Dramatic",
    summary: "Filmisch + episch",
    icon: "🎬",
    instruction:
      "Apply cinematic dramatic grading with depth, high contrast and emotional punch while preserving key subject identity. Do NOT add any text.",
  },
  {
    id: 6,
    name: "Minimalist",
    summary: "Reduziert + extrem lesbar",
    icon: "✨",
    instruction:
      "Create a minimalist thumbnail with less clutter, strong focal hierarchy and clean negative space for maximum readability. Do NOT add any text.",
  },
  {
    id: 7,
    name: "Clean Up",
    summary: "Störendes entfernen (Magic Eraser)",
    icon: "🧹",
    instruction:
      "Clean up this thumbnail by removing visual distractions, clutter, unwanted objects, text overlays, watermarks, and logos. Keep the main subject intact and make the image look professional. Do NOT add any text.",
    subTools: [
      {
        label: "Remove Text",
        description: "Textüberlagerungen entfernen",
        instruction: "Remove all visible text from the image and reconstruct the underlying scene naturally.",
      },
      {
        label: "De-Clutter",
        description: "Kleine Objekte entfernen",
        instruction: "Remove small distracting objects while preserving the main subject and depth.",
      },
      {
        label: "Remove People",
        description: "Störende Personen entfernen",
        instruction: "Remove background people and fill missing areas with realistic context.",
      },
      {
        label: "Remove Logos",
        description: "Markenlogos entfernen",
        instruction: "Erase logos and branding marks, then blend textures to look untouched.",
      },
      {
        label: "Remove Watermarks",
        description: "Wasserzeichen entfernen",
        instruction: "Erase watermark overlays and recover image details underneath.",
      },
      {
        label: "Simplify Background",
        description: "Hintergrund vereinfachen",
        instruction: "Simplify the background to make the subject cleaner and more readable.",
      },
    ],
  },
  {
    id: 8,
    name: "Lighting Studio",
    summary: "Beleuchtung professionell anpassen",
    icon: "💡",
    instruction:
      "Improve the lighting of this thumbnail to look professionally lit. Enhance contrast, add dramatic lighting effects, rim lighting, or studio-quality illumination while keeping the subject intact. Do NOT add any text.",
  },
  {
    id: 9,
    name: "Color Grade",
    summary: "Farbkorrektur + Stimmung",
    icon: "🎨",
    instruction:
      "Apply professional color grading to this thumbnail. Enhance color vibrancy, apply a cinematic color palette, and create a cohesive mood through color treatment. Do NOT add any text.",
  },
  {
    id: 10,
    name: "Expression",
    summary: "Gesichtsausdruck verstärken",
    icon: "😱",
    instruction:
      "Enhance the facial expression in this thumbnail to be more expressive, dramatic, and attention-grabbing while keeping the person recognizable. Do NOT add any text.",
  },
  {
    id: 11,
    name: "Background Swap",
    summary: "Hintergrund austauschen",
    icon: "🌄",
    instruction:
      "Replace the background of this thumbnail with a more visually striking, dramatic, or eye-catching environment while keeping the foreground subject perfectly intact. Do NOT add any text.",
  },
  {
    id: 12,
    name: "Zoom Focus",
    summary: "Fokus auf Hauptmotiv",
    icon: "🔍",
    instruction:
      "Recompose this thumbnail to create a stronger focal point on the main subject. Use depth-of-field effects, vignetting, or selective focus to draw attention in a 16:9 frame. Do NOT add any text.",
  },
];

export const CREATIVITY_OPTIONS = [
  {
    id: "polish",
    name: "Quick",
    subtitle: "Nur optimieren",
  },
  {
    id: "balanced",
    name: "Pro",
    subtitle: "Frischer Look",
  },
  {
    id: "wild",
    name: "Wild",
    subtitle: "Mutige Neuinterpretation",
  },
] as const;
