export type GenerationMode = "generate" | "remix";
export type CreativityLevel = "polish" | "balanced" | "wild";

export interface SubTool {
  label: string;
  description: string;
  instruction: string;
}

export interface ThumbnailTemplate {
  id: number;
  name: string;
  summary: string;
  icon: string;
  instruction: string;
  subTools?: SubTool[];
}

export interface ThumbnailGenerationPayload {
  sourceImage: string;
  skinImage?: string | null;
  prompt?: string;
  mode: GenerationMode;
  templateInstruction?: string;
  subToolInstruction?: string | null;
  creativity: CreativityLevel;
  outputWidth?: number;
  outputHeight?: number;
  plan?: "free" | "pro" | "ultimate";
}

export interface ThumbnailGenerationResponse {
  image: string;
  model: string;
  instruction: string;
}
