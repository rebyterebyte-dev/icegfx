import React, { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { PLAN_CONFIG, type UserPlan } from "@/lib/plans";

interface User {
  id: string;
  email: string;
  name: string;
  credits: number;
  plan: UserPlan;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  signup: (email: string, name: string, password: string) => boolean;
  logout: () => void;
  updateCredits: (amount: number) => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

function normalizeUser(raw: any): User {
  const fallbackPlan: UserPlan = raw?.isPro ? "pro" : "free";
  const plan = (raw?.plan ?? fallbackPlan) as UserPlan;

  return {
    id: raw?.id ?? crypto.randomUUID(),
    email: raw?.email ?? "",
    name: raw?.name ?? "",
    credits: Number.isFinite(raw?.credits) ? raw.credits : PLAN_CONFIG[plan].monthlyCredits,
    plan,
    createdAt: raw?.createdAt ?? new Date().toISOString(),
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("bt_user");
    if (stored) {
      const normalized = normalizeUser(JSON.parse(stored));
      setUser(normalized);
      localStorage.setItem("bt_user", JSON.stringify(normalized));
    }
  }, []);

  const persistUser = (u: User) => {
    setUser(u);
    localStorage.setItem("bt_user", JSON.stringify(u));

    const users: any[] = JSON.parse(localStorage.getItem("bt_users") || "[]");
    const idx = users.findIndex((x) => x.id === u.id);
    if (idx >= 0) {
      users[idx] = { ...users[idx], ...u, isPro: u.plan !== "free" };
      localStorage.setItem("bt_users", JSON.stringify(users));
    }
  };

  const signup = (email: string, name: string, password: string) => {
    const normalizedEmail = email.trim().toLowerCase();
    const normalizedName = name.trim();
    const users: any[] = JSON.parse(localStorage.getItem("bt_users") || "[]");
    if (users.find((u) => String(u.email).trim().toLowerCase() === normalizedEmail)) return false;

    const newUser: User = {
      id: crypto.randomUUID(),
      email: normalizedEmail,
      name: normalizedName,
      credits: PLAN_CONFIG.free.monthlyCredits,
      plan: "free",
      createdAt: new Date().toISOString(),
    };

    users.push({ ...newUser, password, isPro: false });
    localStorage.setItem("bt_users", JSON.stringify(users));
    persistUser(newUser);
    return true;
  };

  const login = (email: string, password: string) => {
    const normalizedEmail = email.trim().toLowerCase();
    const users: any[] = JSON.parse(localStorage.getItem("bt_users") || "[]");
    const found = users.find((u) => String(u.email).trim().toLowerCase() === normalizedEmail && u.password === password);
    if (!found) return false;

    const { password: _, ...safeUser } = found;
    persistUser(normalizeUser(safeUser));
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("bt_user");
  };

  const updateCredits = (amount: number) => {
    if (!user) return;
    const updated = { ...user, credits: Math.max(0, user.credits + amount) };
    persistUser(updated);
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, updateCredits, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
};
