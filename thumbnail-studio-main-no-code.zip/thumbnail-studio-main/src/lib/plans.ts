export type UserPlan = "free" | "pro" | "ultimate";

export const PLAN_CONFIG = {
  free: {
    label: "Free",
    monthlyPrice: "0 €",
    monthlyCredits: 40,
    generations: 4,
    resolution: "720p",
    output: { width: 1280, height: 720 },
  },
  pro: {
    label: "Pro",
    monthlyPrice: "9,99 €",
    monthlyCredits: 500,
    generations: 50,
    resolution: "1080p",
    output: { width: 1920, height: 1080 },
  },
  ultimate: {
    label: "Ultimate",
    monthlyPrice: "35,00 €",
    monthlyCredits: 2000,
    generations: 200,
    resolution: "4K",
    output: { width: 3840, height: 2160 },
  },
} as const;

export function getPlanBadgeClasses(plan: UserPlan) {
  if (plan === "ultimate") return "bg-primary text-primary-foreground";
  if (plan === "pro") return "bg-primary/15 text-primary";
  return "bg-muted text-muted-foreground";
}
