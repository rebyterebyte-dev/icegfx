import { supabase } from "@/integrations/supabase/client";
import type {
  ThumbnailGenerationPayload,
  ThumbnailGenerationResponse,
} from "@/components/dashboard/thumbnail-editor/types";

export async function generateThumbnailWithAI(
  payload: ThumbnailGenerationPayload,
): Promise<ThumbnailGenerationResponse> {
  const { data, error } = await supabase.functions.invoke("generate-thumbnail", {
    body: payload,
  });

  if (error) {
    throw new Error(error.message || "AI request fehlgeschlagen.");
  }

  if (!data?.image) {
    throw new Error("Keine Bilddaten von der AI erhalten.");
  }

  return data as ThumbnailGenerationResponse;
}
