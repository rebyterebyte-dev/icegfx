import { useAuth } from "@/lib/auth-context";
import { PLAN_CONFIG } from "@/lib/plans";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

export default function AccountPage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const plan = user?.plan ?? "free";

  return (
    <div className="p-6 max-w-lg mx-auto">
      <h2 className="text-xl font-bold mb-6">IdeaMinds Account</h2>
      <div className="space-y-4 p-6 rounded-xl bg-card border border-border">
        <div><span className="text-xs text-muted-foreground">Name</span><p className="font-medium">{user?.name}</p></div>
        <div><span className="text-xs text-muted-foreground">E-Mail</span><p className="font-medium">{user?.email}</p></div>
        <div><span className="text-xs text-muted-foreground">Credits</span><p className="font-medium text-primary">{user?.credits}</p></div>
        <div><span className="text-xs text-muted-foreground">Plan</span><p className="font-medium">{PLAN_CONFIG[plan].label}</p></div>
        <div><span className="text-xs text-muted-foreground">Qualität</span><p className="font-medium">{PLAN_CONFIG[plan].resolution}</p></div>
        <div><span className="text-xs text-muted-foreground">Mitglied seit</span><p className="font-medium">{user?.createdAt ? new Date(user.createdAt).toLocaleDateString("de-DE") : "-"}</p></div>
        <Button variant="destructive" className="w-full mt-4" onClick={() => { logout(); navigate("/"); }}>Logout</Button>
      </div>
    </div>
  );
}
