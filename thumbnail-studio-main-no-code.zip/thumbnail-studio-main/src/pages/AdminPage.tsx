import { useState } from "react";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";
import { PLAN_CONFIG, type UserPlan } from "@/lib/plans";

const ADMIN_PASSWORD = "bytethumb";

export default function AdminPage() {
  const [password, setPassword] = useState("");
  const [authenticated, setAuthenticated] = useState(false);
  const [users, setUsers] = useState<any[]>([]);

  const handleLogin = () => {
    if (password === ADMIN_PASSWORD) {
      setAuthenticated(true);
      const allUsers = JSON.parse(localStorage.getItem("bt_users") || "[]").map((u: any) => ({
        ...u,
        plan: u.plan ?? (u.isPro ? "pro" : "free"),
      }));
      localStorage.setItem("bt_users", JSON.stringify(allUsers));
      setUsers(allUsers);
    } else {
      toast({ title: "Falsches Passwort", variant: "destructive" });
    }
  };

  const updateUser = (id: string, updates: any) => {
    const allUsers = JSON.parse(localStorage.getItem("bt_users") || "[]");
    const idx = allUsers.findIndex((u: any) => u.id === id);
    if (idx >= 0) {
      const next = { ...allUsers[idx], ...updates };
      next.isPro = next.plan !== "free";
      allUsers[idx] = next;

      localStorage.setItem("bt_users", JSON.stringify(allUsers));
      setUsers([...allUsers]);

      const currentUser = JSON.parse(localStorage.getItem("bt_user") || "{}");
      if (currentUser.id === id) {
        localStorage.setItem("bt_user", JSON.stringify({ ...currentUser, ...next }));
      }

      toast({ title: "Aktualisiert" });
    }
  };

  const assignPlan = (id: string, plan: UserPlan) => {
    updateUser(id, { plan, credits: PLAN_CONFIG[plan].monthlyCredits });
  };

  if (!authenticated) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[60vh]">
        <div className="w-full max-w-xs space-y-4 text-center">
          <Shield className="h-10 w-10 text-primary mx-auto" />
          <h2 className="text-lg font-bold">IdeaMinds Admin</h2>
          <Input
            type="password"
            placeholder="Admin Passwort"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleLogin()}
          />
          <Button className="w-full" onClick={handleLogin}>Einloggen</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-6 flex items-center gap-2"><Shield className="h-5 w-5 text-primary" /> IdeaMinds Admin Panel</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[920px]">
          <thead>
            <tr className="border-b border-border text-left">
              <th className="p-3 text-muted-foreground font-medium">Name</th>
              <th className="p-3 text-muted-foreground font-medium">E-Mail</th>
              <th className="p-3 text-muted-foreground font-medium">Credits</th>
              <th className="p-3 text-muted-foreground font-medium">Plan</th>
              <th className="p-3 text-muted-foreground font-medium">Aktionen</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => {
              const plan = (u.plan ?? (u.isPro ? "pro" : "free")) as UserPlan;
              return (
                <tr key={u.id} className="border-b border-border/50">
                  <td className="p-3">{u.name}</td>
                  <td className="p-3 text-muted-foreground">{u.email}</td>
                  <td className="p-3">
                    <Input
                      type="number"
                      value={u.credits}
                      className="w-24 h-8 text-xs"
                      onChange={(e) => updateUser(u.id, { credits: parseInt(e.target.value) || 0 })}
                    />
                  </td>
                  <td className="p-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      plan === "ultimate" ? "bg-primary text-primary-foreground" :
                      plan === "pro" ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"
                    }`}>
                      {PLAN_CONFIG[plan].label}
                    </span>
                  </td>
                  <td className="p-3">
                    <div className="flex gap-2 flex-wrap">
                      <Button size="sm" variant="outline" onClick={() => assignPlan(u.id, "free")}>Free</Button>
                      <Button size="sm" variant="outline" onClick={() => assignPlan(u.id, "pro")}>Give Pro</Button>
                      <Button size="sm" variant="outline" onClick={() => assignPlan(u.id, "ultimate")}>Give Ultimate</Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
