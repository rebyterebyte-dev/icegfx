import { useAuth } from "@/lib/auth-context";
import { PLAN_CONFIG } from "@/lib/plans";
import { Zap, CreditCard, Check } from "lucide-react";

const plans = [
  {
    key: "free" as const,
    title: "Free",
    price: "0 € / Monat",
    credits: "40 Credits (4 Generationen)",
    quality: "720p",
  },
  {
    key: "pro" as const,
    title: "Pro",
    price: "9,99 € / Monat",
    credits: "500 Credits",
    quality: "1080p",
  },
  {
    key: "ultimate" as const,
    title: "Ultimate",
    price: "35,00 € / Monat",
    credits: "2000 Credits",
    quality: "4K",
  },
];

export default function CreditsPage() {
  const { user } = useAuth();
  const activePlan = user?.plan ?? "free";

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h2 className="text-xl font-bold mb-6">IdeaMinds Credits & Plans</h2>

      <div className="p-6 rounded-xl bg-card border border-border mb-6">
        <div className="flex items-center gap-3 mb-4">
          <Zap className="h-6 w-6 text-primary" />
          <div>
            <p className="text-sm text-muted-foreground">Verfügbare Credits</p>
            <p className="text-3xl font-bold text-primary">{user?.credits ?? 0}</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">1 Thumbnail = 10 Credits</p>
        <p className="text-sm mt-1">Aktiver Plan: <span className="text-primary font-medium">{PLAN_CONFIG[activePlan].label}</span></p>
      </div>

      <div className="grid md:grid-cols-3 gap-4 mb-6">
        {plans.map((plan) => (
          <div
            key={plan.key}
            className={`rounded-xl border p-5 ${activePlan === plan.key ? "border-primary bg-primary/10" : "border-border bg-card"}`}
          >
            <h3 className="font-semibold text-lg mb-1">{plan.title}</h3>
            <p className="text-sm text-muted-foreground mb-3">{plan.price}</p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> {plan.credits}</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> {plan.quality} Ausgabe</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> 10 Credits pro Thumbnail</li>
            </ul>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-xl bg-card border border-primary/30">
        <h3 className="font-semibold flex items-center gap-2 mb-3"><CreditCard className="h-4 w-4" /> Zahlung</h3>
        <p className="text-sm text-muted-foreground mb-2">Bezahlen per PayPal:</p>
        <p className="text-sm font-medium text-foreground mb-4 break-all">rebyterebyte@gmail.com</p>
        <p className="text-xs text-muted-foreground">
          Nach Zahlung wird dein Plan im Admin Panel auf <strong>Pro</strong> oder <strong>Ultimate</strong> gesetzt.
        </p>
      </div>
    </div>
  );
}
