import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Check, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

const stats = [
  { value: "2,500+", label: "Creators with IdeaMinds" },
  { value: "47%", label: "Average CTR increase" },
  { value: "<5s", label: "Generation time" },
  { value: "10+", label: "Supported game styles" },
];

const testimonials = [
  "My CTR went from 4.2% to 7.1% after switching to IdeaMinds.",
  "I used to spend 2 hours per thumbnail. Now it takes 3 minutes.",
  "Skin Replacer alone is worth it. Works with my Minecraft skin.",
  "The cleanup + remix tools made my thumbnails way more clickable.",
  "Best investment I made for my channel.",
  "Perfect for creators without a design budget.",
];

const plans = [
  {
    name: "Free",
    price: "0 €",
    description: "Für Starter",
    credits: "40 Credits / Monat (4 Generationen)",
    quality: "720p Ausgabe",
    features: ["Basic templates", "10 Credits pro Thumbnail", "Drag & Drop + Download"],
  },
  {
    name: "Pro",
    price: "9,99 €",
    description: "Für Creator",
    credits: "500 Credits / Monat",
    quality: "1080p Ausgabe",
    features: ["Alle Templates", "Skin Replacement + Remix", "Clean Up & Premium Tools"],
    highlighted: true,
  },
  {
    name: "Ultimate",
    price: "35,00 €",
    description: "Für Power-User",
    credits: "2000 Credits / Monat",
    quality: "4K Ausgabe",
    features: ["Alles aus Pro", "Maximale Qualität", "Priorisierte kreative Varianten"],
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <nav className="sticky top-0 z-30 border-b border-border/60 bg-background/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="text-xl font-bold tracking-tight">⚡ IdeaMinds</Link>
          <div className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
            <a href="#features" className="hover:text-foreground transition-colors">Features</a>
            <a href="#how" className="hover:text-foreground transition-colors">How it works</a>
            <a href="#testimonials" className="hover:text-foreground transition-colors">Testimonials</a>
            <a href="#pricing" className="hover:text-foreground transition-colors">Pricing</a>
          </div>
          <Button asChild className="rounded-full px-6"><Link to="/login">Dashboard</Link></Button>
        </div>
      </nav>

      <section className="px-6 pt-20 pb-14 text-center border-b border-border/50">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="max-w-4xl mx-auto">
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-medium bg-secondary border border-border text-muted-foreground mb-8">Powered by AI. No limits.</span>
          <h1 className="text-5xl md:text-7xl font-bold leading-[0.95] tracking-tight mb-6">Viral Thumbnails.<br /><span className="text-muted-foreground">In Seconds.</span></h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">Erstelle scroll-stoppende YouTube Thumbnails mit Skin Replacement, Clean Up und Remix – ohne komplexe Designsoftware.</p>
          <div className="flex justify-center gap-3">
            <Button size="lg" asChild className="rounded-full px-8"><Link to="/signup">Open Studio <ArrowRight className="h-4 w-4 ml-1" /></Link></Button>
            <Button size="lg" variant="outline" asChild className="rounded-full px-8"><Link to="/login">Login</Link></Button>
          </div>
        </motion.div>
      </section>

      <section className="px-6 py-10 border-b border-border/50">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {stats.map((stat) => (
            <div key={stat.label}>
              <p className="text-4xl font-bold">{stat.value}</p>
              <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="how" className="px-6 py-20 border-b border-border/50">
        <div className="max-w-4xl mx-auto text-center mb-10">
          <h2 className="text-4xl font-bold mb-3">From Draft to Masterpiece</h2>
          <p className="text-muted-foreground">Upload → Skin einsetzen → Tool wählen → in Sekunden exportieren.</p>
        </div>
        <div className="max-w-4xl mx-auto rounded-3xl border border-border overflow-hidden bg-card">
          <div className="grid md:grid-cols-2">
            <div className="p-8 border-b md:border-b-0 md:border-r border-border">
              <span className="inline-flex text-xs px-3 py-1 rounded-full bg-secondary border border-border mb-4">Before</span>
              <p className="text-2xl font-semibold mb-2">Rohes Thumbnail</p>
              <p className="text-sm text-muted-foreground">Unruhig, schwach ausgeleuchtet, wenig Fokus.</p>
            </div>
            <div className="p-8">
              <span className="inline-flex text-xs px-3 py-1 rounded-full bg-primary text-primary-foreground mb-4">After</span>
              <p className="text-2xl font-semibold mb-2">IdeaMinds Result</p>
              <p className="text-sm text-muted-foreground">Klarer Fokus, starke Farben, bessere Klickrate.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="testimonials" className="px-6 py-20 border-b border-border/50">
        <div className="max-w-4xl mx-auto text-center mb-10">
          <span className="inline-flex text-xs px-3 py-1 rounded-full bg-secondary border border-border mb-4">Creator Love</span>
          <h2 className="text-4xl font-bold">Creators who switched never looked back.</h2>
        </div>
        <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-4">
          {testimonials.map((quote, i) => (
            <div key={i} className="rounded-2xl border border-border bg-card p-5">
              <div className="flex gap-1 mb-3">{Array.from({ length: 5 }).map((_, s) => <Star key={s} className="h-3.5 w-3.5 fill-current text-foreground" />)}</div>
              <p className="text-sm text-muted-foreground">"{quote}"</p>
            </div>
          ))}
        </div>
      </section>

      <section id="pricing" className="px-6 py-20">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2 className="text-5xl font-bold mb-3">Simple pricing.</h2>
          <p className="text-xl text-muted-foreground">Start for free. Upgrade when you need more power.</p>
        </div>

        <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div key={plan.name} className={`rounded-3xl border p-7 ${plan.highlighted ? "border-primary bg-primary/10" : "border-border bg-card"}`}>
              <h3 className="text-2xl font-semibold mb-1">{plan.name}</h3>
              <p className="text-muted-foreground mb-4">{plan.description}</p>
              <p className="text-5xl font-bold mb-1">{plan.price}</p>
              <p className="text-sm text-muted-foreground mb-5">/ Monat</p>
              <p className="text-base mb-1">{plan.credits}</p>
              <p className="text-base text-muted-foreground mb-6">{plan.quality}</p>
              <ul className="space-y-3 mb-8 text-sm">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> {f}</li>
                ))}
              </ul>
              <Button asChild className="w-full rounded-full" variant={plan.highlighted ? "default" : "outline"}>
                <Link to="/signup">Get Started</Link>
              </Button>
            </div>
          ))}
        </div>

        <div className="max-w-4xl mx-auto mt-10 rounded-2xl border border-border bg-card p-6 text-center">
          <p className="text-sm text-muted-foreground mb-1">Zahlung per PayPal</p>
          <p className="text-lg font-semibold">rebyterebyte@gmail.com</p>
          <p className="text-xs text-muted-foreground mt-3">Nach Zahlung wird dein Plan im Admin Panel manuell auf Pro oder Ultimate gesetzt.</p>
        </div>
      </section>

      <footer className="border-t border-border/60 py-8 text-center text-sm text-muted-foreground">
        © 2026 IdeaMinds. All rights reserved.
      </footer>
    </div>
  );
}
