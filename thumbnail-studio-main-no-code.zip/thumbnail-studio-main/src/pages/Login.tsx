import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(email, password)) {
      navigate("/dashboard");
    } else {
      toast({ title: "Fehler", description: "E-Mail oder Passwort falsch.", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="text-center">
          <Link to="/" className="text-2xl font-bold text-primary">⚡ IdeaMinds</Link>
          <p className="text-muted-foreground mt-2">Login</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div><Label>E-Mail</Label><Input type="email" value={email} onChange={e => setEmail(e.target.value)} required /></div>
          <div><Label>Passwort</Label><Input type="password" value={password} onChange={e => setPassword(e.target.value)} required /></div>
          <Button className="w-full" type="submit">Login</Button>
        </form>
        <p className="text-center text-sm text-muted-foreground">
          Noch kein Account? <Link to="/signup" className="text-primary hover:underline">Sign Up</Link>
        </p>
      </div>
    </div>
  );
}
