import { useAuth } from "@/lib/auth-context";
import { Download, ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

type ThumbItem = {
  id: string;
  image: string;
  fullImage?: string | null;
  createdAt: string;
  userId: string;
};

export default function MyThumbnails() {
  const { user } = useAuth();
  let all: ThumbItem[] = [];

  try {
    all = JSON.parse(localStorage.getItem("bt_thumbnails") || "[]");
  } catch {
    all = [];
  }

  const thumbnails = all.filter((t) => t.userId === user?.id);

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-6">My Thumbnails</h2>
      {thumbnails.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground">
          <ImageIcon className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p>Noch keine Thumbnails erstellt.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {thumbnails.map((t) => (
            <div key={t.id} className="rounded-lg border border-border bg-card overflow-hidden group">
              <div className="aspect-video bg-muted">
                {t.image ? (
                  <img src={t.image} alt="Thumbnail" className="w-full h-full object-cover" loading="lazy" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground">Keine Vorschau</div>
                )}
              </div>
              <div className="p-3 flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{new Date(t.createdAt).toLocaleDateString("de-DE")}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    const a = document.createElement("a");
                    a.href = t.fullImage || t.image;
                    a.download = `thumbnail-${t.id}.png`;
                    a.click();
                  }}
                  disabled={!t.image}
                >
                  <Download className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
