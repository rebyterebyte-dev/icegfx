import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (signup(email, name, password)) {
      toast({ title: "Willkommen bei IdeaMinds!", description: "Dein Account wurde direkt erstellt – ohne Verifizierungscode. Du hast 40 Credits erhalten." });
      navigate("/dashboard");
    } else {
      toast({ title: "Fehler", description: "E-Mail bereits registriert.", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="text-center">
          <Link to="/" className="text-2xl font-bold text-primary">⚡ IdeaMinds</Link>
          <p className="text-muted-foreground mt-2">Account erstellen – ohne Verifizierungscode</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div><Label>Name</Label><Input value={name} onChange={e => setName(e.target.value)} required /></div>
          <div><Label>E-Mail</Label><Input type="email" value={email} onChange={e => setEmail(e.target.value)} required /></div>
          <div><Label>Passwort</Label><Input type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={6} /></div>
          <Button className="w-full" type="submit">Jetzt registrieren</Button>
        </form>
        <p className="text-center text-sm text-muted-foreground">
          Bereits ein Account? <Link to="/login" className="text-primary hover:underline">Login</Link>
        </p>
      </div>
    </div>
  );
}
