import { ThumbnailEditor } from "@/components/dashboard/ThumbnailEditor";

export default function StudioPage() {
  return <ThumbnailEditor />;
}
