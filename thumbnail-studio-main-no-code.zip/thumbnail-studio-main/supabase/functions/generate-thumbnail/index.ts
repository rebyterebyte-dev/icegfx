import { corsHeaders } from "../_shared/cors.ts";

type GenerationMode = "generate" | "remix";
type CreativityLevel = "polish" | "balanced" | "wild";
type UserPlan = "free" | "pro" | "ultimate";

interface GenerationRequest {
  sourceImage: string;
  skinImage?: string | null;
  prompt?: string;
  mode: GenerationMode;
  templateInstruction?: string;
  subToolInstruction?: string | null;
  creativity: CreativityLevel;
  outputWidth?: number;
  outputHeight?: number;
  plan?: UserPlan;
}

const creativityInstruction: Record<CreativityLevel, string> = {
  polish: "Keep composition very close to original and only optimize quality.",
  balanced: "Keep subject and concept, but improve lighting, contrast and focus.",
  wild: "Create a bold remix while preserving recognizability.",
};

const planInstruction: Record<UserPlan, string> = {
  free: "Output quality target: sharp 720p result.",
  pro: "Output quality target: high-detail 1080p result.",
  ultimate: "Output quality target: very high-detail 4K-style result.",
};

function cleanBase64(input: string): string {
  return input
    .replace(/^data:[^;]+;base64,/i, "")
    .replace(/\s/g, "");
}

function normalizeImageInput(input: string): string {
  if (input.startsWith("http://") || input.startsWith("https://") || input.startsWith("data:image/")) {
    return input;
  }
  const cleaned = cleanBase64(input);
  return `data:image/png;base64,${cleaned}`;
}

function buildInstruction(payload: GenerationRequest): string {
  const targetWidth = payload.outputWidth ?? 1280;
  const targetHeight = payload.outputHeight ?? 720;

  const parts = [
    "MANDATORY: Return an edited/generated IMAGE, never text-only output.",
    payload.mode === "remix" ? "Create a fresh remix variant of this thumbnail." : "Generate an improved thumbnail from this source image.",
    `MANDATORY: Keep EXACT 16:9 composition and output ${targetWidth}x${targetHeight}.`,
    "MANDATORY: Do NOT add any text, title, caption, logo, watermark, or letters.",
    payload.templateInstruction || "",
    payload.subToolInstruction || "",
    creativityInstruction[payload.creativity],
    payload.plan ? planInstruction[payload.plan] : "",
    payload.skinImage
      ? "CRITICAL SKIN REPLACEMENT: Replace the person/character with the uploaded skin reference while preserving exact pose, camera angle, body position, framing, and scene geometry. Keep character proportions natural and integrated."
      : "",
    payload.prompt?.trim() || "",
  ];

  return parts.filter(Boolean).join("\n");
}

async function callAI(apiKey: string, content: Array<Record<string, unknown>>): Promise<string | null> {
  const model = "google/gemini-3.1-flash-image-preview";

  const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      messages: [{ role: "user", content }],
      modalities: ["image", "text"],
    }),
  });

  if (!aiResponse.ok) {
    const failureText = await aiResponse.text();

    if (aiResponse.status === 429) {
      throw { status: 429, message: "Rate limit erreicht. Bitte kurz warten." };
    }
    if (aiResponse.status === 402) {
      throw { status: 402, message: "Keine AI-Credits mehr verfügbar." };
    }

    throw { status: 502, message: "AI provider error", details: failureText };
  }

  const data = await aiResponse.json();
  return data?.choices?.[0]?.message?.images?.[0]?.image_url?.url ?? null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const body = (await req.json()) as GenerationRequest;

    if (!body?.sourceImage) {
      return new Response(JSON.stringify({ error: "sourceImage is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) throw new Error("LOVABLE_API_KEY is missing");

    const instruction = buildInstruction(body);

    const content: Array<Record<string, unknown>> = [
      { type: "text", text: instruction },
      { type: "image_url", image_url: { url: normalizeImageInput(body.sourceImage) } },
    ];

    if (body.skinImage) {
      content.push({ type: "image_url", image_url: { url: normalizeImageInput(body.skinImage) } });
    }

    const MAX_RETRIES = 3;
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      const image = await callAI(apiKey, content);
      if (image) {
        return new Response(JSON.stringify({ image, instruction, model: "google/gemini-3.1-flash-image-preview" }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    return new Response(JSON.stringify({ error: "AI returned no image" }), {
      status: 502,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    if (error && typeof error === "object" && "status" in error) {
      const e = error as { status: number; message: string; details?: string };
      return new Response(JSON.stringify({ error: e.message, details: e.details }), {
        status: e.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
